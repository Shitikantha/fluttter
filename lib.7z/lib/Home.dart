import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'NavigateDrawer.dart';
import 'MyAppBar.dart';
import 'package:flutter_session/flutter_session.dart';

import 'email_login.dart';

class Home extends StatelessWidget {
  Home({this.uid});
  final String? uid;
  final String title = "Home";

  var session = FlutterSession();
  bool isLogin = false;
  String text = "";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getSession();
    print("session == " + isLogin.toString());
  }

  _getSession() async {
    isLogin = await FlutterSession().get("isLogin");
    setState(() {
      text = isLogin.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: MyAppBar().buildAppBar(context, "Home"),
        body: Center(child: Text('Welcome!')),
        drawer: NavigateDrawer(uid: uid));
  }
}
