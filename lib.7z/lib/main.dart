import 'package:flutter/material.dart';
import 'package:loginuicolors/register.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'email_login.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: "AIzaSyADz9EDrpl5Y_ZHlmnBuzDjtjH8wt89AvQ",
          authDomain: "firstapp-b1384.firebaseapp.com",
          databaseURL: "https://firstapp-b1384-default-rtdb.firebaseio.com",
          projectId: "firstapp-b1384",
          storageBucket: "firstapp-b1384.appspot.com",
          messagingSenderId: "726651417830",
          appId: "1:726651417830:web:277c67c1a60e23c2647727",
          measurementId: "G-K068RYCW3Q"));

  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyRegister(),
    routes: {
      'register': (context) => MyRegister(),
      //'login': (context) => MyLogin(),
    },
  ));
}
