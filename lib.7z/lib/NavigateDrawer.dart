import 'package:firebase_auth/firebase_auth.dart';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'Home.dart';
import 'Settings.dart';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:convert';

class NavigateDrawer extends StatefulWidget {
  final String? uid;
  NavigateDrawer({Key? key, this.uid}) : super(key: key);
  @override
  _NavigateDrawerState createState() => _NavigateDrawerState(uid);
}

class _NavigateDrawerState extends State<NavigateDrawer> {
  final String? uid;

  _NavigateDrawerState(this.uid) {}
  @override
  void initState() {
    super.initState();
    print('hi there');
    loadUserDetails(uid.toString(), userName);
    print('hi Here');
  }

  // Method to set the user's email
  String userName = '';
  loadUserDetails(String userId, String userName) async {
    final ref = FirebaseDatabase.instance.ref();
    print("this.uid.toString()" + this.uid.toString());
    final snapshot = await ref.child('Users/' + this.uid.toString()).get();
    if (snapshot.exists) {
      Map<String, dynamic> dataMap = snapshot.value as Map<String, dynamic>;
      userName = dataMap['name'];
      print("userName::" + userName);
    } else {
      print('No data available.');
    }

    return Text(userName);
  }

  @override
  Widget build(BuildContext context) {
    String emailId = 'Default';
    print('after load ::' + this.userName);
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountEmail: Text(""),
            accountName: Text(this.userName),
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
          ),
          ListTile(
            leading: new IconButton(
              icon: new Icon(Icons.home, color: Colors.black),
              onPressed: () => null,
            ),
            title: Text('Home'),
            onTap: () {
              print(widget.uid);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Home(uid: widget.uid)),
              );
            },
          ),
          ListTile(
            leading: new IconButton(
              icon: new Icon(Icons.settings, color: Colors.black),
              onPressed: () => null,
            ),
            title: Text('Settings'),
            onTap: () {
              print(widget.uid);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Home(uid: widget.uid)),
              );
            },
          ),
          ListTile(
            leading: new IconButton(
              icon: new Icon(Icons.settings, color: Colors.red),
              onPressed: () => null,
            ),
            title: Text('Quiz'),
            onTap: () {
              print(widget.uid);
            },
          ),
        ],
      ),
    );
  }
}
